library(shiny)
library(pROC)
library(bslib)
library(dplyr)

# --- Core function ---
ROC_sample_size <- function(mu1, sd1, mu2, sd2,
                            AUC_ref = 0.5, k = 1, prev = NULL,
                            alpha = 0.05, power = 0.8,
                            max_size = 500, two_sided = FALSE,
                            seed = NULL, min_size = 5, n_of_rep = 2000,
                            num_of_tests = 1,
                            progress_cb = NULL) {
  
  alpha <- alpha / num_of_tests
  
  if (!is.null(seed)) set.seed(seed)
  if (!two_sided) alpha <- alpha * 2
  
  if (is.null(prev) & !is.null(k)) {
    message("If the ratio of positive to negative sample sizes in your data differs from that in the population, the calculated PPV/NPV may be incorrect.")
  } else if (!is.null(prev) & is.null(k)) {
    k <- prev / (1 - prev)
  } else if (!is.null(prev) & !is.null(k)) {
    warning("Both prev and k provided: using k and ignoring prev.")
  } else if (is.null(prev) & is.null(k)) {
    stop("prevalence or k must be provided")
  }
  
  if (round(min_size * k) < 5) {
    while (round(min_size * k) < 5) min_size <- min_size + 1
  }
  
  int <- max_size - min_size
  
  n_seq <- c(
    seq(min_size, min_size + round(int / 4), 2),
    seq(min_size + round(int / 4) + 3, min_size + round(int / 2), 3),
    seq(min_size + round(int / 2) + 4, min_size + round(3 * int / 4), 4),
    seq(min_size + round(3 * (int / 4)) + 5, max_size, 5)
  )
  total_iter <- length(n_seq)
  iter <- 0
  
  for (n in n_seq) {
    iter <- iter + 1
    if (!is.null(progress_cb)) progress_cb(iter, total_iter, n)
    
    AUC_data <- replicate(
      n = n_of_rep,
      pROC::ci.auc(
        predictor = c(
          rnorm(n = round(k * n), mu1, sd1),
          rnorm(n = n, mu2, sd2)
        ),
        response = c(rep(1, round(n * k)), rep(0, n)),
        method = "delong",
        conf.level = 1 - alpha
      )
    ) %>% as_tibble()
    
    CI_low <- AUC_data %>% slice(1) %>% as.matrix() %>% as.vector()
    AUC_test <- AUC_data %>% slice(2) %>% as.matrix() %>% as.vector()
    
    CI_low[CI_low == 1] <- NA
    sim_power <- mean(CI_low > AUC_ref, na.rm = TRUE)
    mean_AUC <- mean(AUC_test, na.rm = TRUE)
    
    if (sim_power > power) {
      return(list(
        n_neg = n,
        n_pos = round(k * n),
        sim_power = sim_power,
        mean_AUC = mean_AUC
      ))
    }
  }
  
  return(NULL)
}

# --- UI ---
ui <- page_fillable(
  theme = bs_theme(
    version = 5,
    bg = "#0f1b3d",
    fg = "#e6eefb",
    primary = "#60a5fa",
    input_bg = "#2b2f3a",
    input_border = "#2f3a66",
    input_fg = "#e6eefb"
  ),
  
  tags$head(tags$style(HTML("
    .container-xl{max-width:1200px}
    .app-title{ font-size:34px; font-weight:700; letter-spacing:.3px; margin-bottom:18px }
    .card, .well, .panel, .panel-default{
      background: linear-gradient(180deg,#0c1737,#0a1531);
      border:1px solid #2f3a66 !important;
      box-shadow:0 8px 24px rgba(11,22,54,.45);
      border-radius:16px !important;
    }
    .shiny-input-container>label, .control-label{ color:#a7b4d6 !important; font-weight:600 }
    .form-control, .selectize-input{
      background:#2b2f3a !important; color:#e6eefb !important;
      border:1px solid #2f3a66 !important; border-radius:12px !important;
      height:44px; box-shadow:none;
    }
    .btn-primary{
      background:#3b82f6; border-color:#3b82f6;
      border-radius:12px; padding:10px 18px; font-weight:700;
      transition: box-shadow .2s ease, transform .08s ease;
    }
    .btn-primary:hover{ background:#2563eb; border-color:#2563eb;
      box-shadow:0 0 16px rgba(96,165,250,.45); transform:translateY(-1px) }
    .logo-card img{
      width:100%; height:auto; display:block; border-radius:18px;
      box-shadow:0 0 24px rgba(86,140,255,.45), 0 0 64px rgba(86,140,255,.25);
    }
    .card-body{ padding:20px 22px }
  "))),
  
  div(class = "container-xl py-4",
      div(class = "app-title", "ROC Sample Size Calculator"),
      layout_columns(
        col_widths = c(5, 7), gap = "24px",
        
        bslib::card(
          bslib::card_body(
            numericInput("mu1", "Mean (diseased, mu1):", value = 5, step = 0.1),
            numericInput("sd1", "SD (diseased, sd1):", value = 1, step = 0.1),
            numericInput("mu2", "Mean (healthy, mu2):", value = 3, step = 0.1),
            numericInput("sd2", "SD (healthy, sd2):", value = 1, step = 0.1),
            numericInput("AUC_ref", "Reference AUC:", value = 0.5, min = 0, max = 1, step = 0.01),
            numericInput("k", "Ratio k:", value = 1, min = 0.01, step = 0.01),
            numericInput("prev", "Disease prevalence:", value = NA, min = 0, max = 1, step = 0.01),
            numericInput("alpha", "Type I error:", value = 0.05, min = 0, max = 1, step = 0.005),
            numericInput("power", "Desired power:", value = 0.8, min = 0, max = 1, step = 0.01),
            numericInput("max_size", "Max n (neg group):", value = 500, min = 10, step = 1),
            checkboxInput("two_sided", "Two-sided test", value = FALSE),
            numericInput("seed", "Random seed:", value = NA),
            numericInput("min_size", "Min n (neg group):", value = 5, min = 5, step = 1),
            numericInput("n_of_rep", "Number of replications:", value = 2000, min = 100, step = 100),
            numericInput("num_of_tests", "Number of tests planned:", value = 1, min = 1, step = 1),
            div(style = "margin-top:12px",
                actionButton("run_calc", "Run calculation", class = "btn btn-primary", width = "100%")
            )
          )
        ),
        
        div(
          bslib::card(class = "logo-card",
                      bslib::card_body(
                        img(src = "logo.png", alt = "DiagPower logo")
                      )
          ),
          div(style = "height:16px"),
          bslib::card(
            bslib::card_body(
              h4("Results"),
              verbatimTextOutput("calc_results")
            )
          )
        )
      )
  )
)

# --- Server ---
server <- function(input, output) {
  observeEvent(input$run_calc, {
    prev_val <- if (is.null(input$prev) || is.na(input$prev)) NULL else input$prev
    seed_val <- {
      s <- input$seed
      if (is.null(s) || is.na(s) || !is.finite(s)) NULL else as.integer(s)
    }
    
    withProgress(message = "Running simulation...", value = 0, {
      progress_cb <- function(iter, total_iter, n_now) {
        incProgress(1 / total_iter, detail = paste0("n (negative group) = ", n_now))
      }
      
      res <- ROC_sample_size(
        mu1 = input$mu1, sd1 = input$sd1,
        mu2 = input$mu2, sd2 = input$sd2,
        AUC_ref = input$AUC_ref,
        k = input$k,
        prev = prev_val,
        alpha = input$alpha,
        power = input$power,
        max_size = input$max_size,
        two_sided = input$two_sided,
        seed = seed_val,
        min_size = input$min_size,
        n_of_rep = input$n_of_rep,
        num_of_tests = input$num_of_tests,
        progress_cb = progress_cb
      )
      
      if (is.null(res)) {
        output$calc_results <- renderText("Desired power not reached.")
      } else {
        output$calc_results <- renderText(sprintf(
          "Negative group size: %d\nPositive group size: %d\nPower: %.2f%%\nMean AUC: %.3f",
          res$n_neg, res$n_pos, res$sim_power * 100, res$mean_AUC
        ))
      }
    })
  })
}

shinyApp(ui, server)
